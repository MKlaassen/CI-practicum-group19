package Maze;
public enum Direction {
    EAST, WEST, SOUTH, NORTH;
}
