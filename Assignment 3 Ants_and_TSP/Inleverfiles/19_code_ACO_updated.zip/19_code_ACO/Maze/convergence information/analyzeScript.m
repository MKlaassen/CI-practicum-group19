clear all;
close all;

mazeDifficulty = 'hard';
ColorSet = distinguishable_colors(20);

for h=1:20;
    
    filename = ['C:\Users\Daniel\Java\workspace\19_code_ACO\Maze\convergence information\' mazeDifficulty '\compactConvergenceInformation_' num2str(h-1) '_.txt'];
    %disp(filename);
    delimiter = '';
    
    formatSpec = '%f%[^\n\r]';
    
    fileID = fopen(filename,'r');
    
    dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter,  'ReturnOnError', false);
    
    fclose(fileID);
     
    plot(dataArray{:, 1}(1:20), 'Color', ColorSet(h,:));
    %plot(dataArray{:, 1}(1:50), 'Color', ColorSet(h,:));
    title(['Amount of steps before reaching endpoint in ' mazeDifficulty ' maze; Q = abs(startcoord(x,y)-endcoord(x,y))'])
    ylabel('Steps')
    xlabel('Winner no.')
    %xlim([1 20]);
    hold on;
    
    clearvars filename delimiter formatSpec fileID dataArray ans;
end

    %legend('1xQ','2xQ','3xQ','4xQ','5xQ','6xQ','7xQ','8xQ','9xQ','10xQ');
    legend('5xQ','10xQ','15xQ','20xQ','25xQ','30xQ','35xQ','40xQ','45xQ','50xQ','55xQ','60xQ','65xQ','70xQ','75xQ','80xQ','85xQ','90xQ','95xQ','100xQ');
