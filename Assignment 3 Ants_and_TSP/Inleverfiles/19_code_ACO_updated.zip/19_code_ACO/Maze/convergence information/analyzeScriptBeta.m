clear all;
close all;

mazeDifficulty = 'insane';
ColorSet = distinguishable_colors(20);

for h=1:10;
    
    filename = ['C:\Users\Daniel\Java\workspace\19_code_ACO\Maze\convergence information\' mazeDifficulty '\compactConvergenceInformation_' num2str(h-1) '_.txt'];
    filename2 = ['C:\Users\Daniel\Java\workspace\19_code_ACO\Maze\convergence information\varying Beta no.1\' mazeDifficulty '\compactConvergenceInformation_' num2str(h-1) '_.txt'];
    %disp(filename);
    delimiter = '';
    
    formatSpec = '%f%[^\n\r]';
    
    fileID = fopen(filename,'r');
    fileID2 = fopen(filename2,'r');
    
    dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter,  'ReturnOnError', false);
    dataArray2 = textscan(fileID2, formatSpec, 'Delimiter', delimiter,  'ReturnOnError', false);
    
    fclose(fileID);
    fclose(fileID2);
    
    temp = [dataArray{1:end-1}];
    temp2 = [dataArray2{1:end-1}];
    
    minimal = min(temp);
    minimal2 = min(temp2);
    averageMinimal = (minimal+minimal2)/2;
     
    %stem(h,minimal, 'Color', ColorSet(h,:));

    %plot(dataArray{:, 1}(1:20), 'Color', ColorSet(h,:));
    stem(h*0.1,averageMinimal, 'Color', ColorSet(h,:));
    %plot(dataArray{:, 1}(1:50), 'Color', ColorSet(h,:));
    title(['Amount of steps before reaching endpoint in ' mazeDifficulty ';Average over 2 measurements']);
    ylabel('Steps')
    xlabel('Beta')
    %xlim([1 20]);
    hold on;
    
    clearvars filename delimiter formatSpec fileID dataArray ans;
end

    %legend('Beta = 0.1','Beta = 0.2','Beta = 0.3','Beta = 0.4','Beta = 0.5','Beta = 0.6','Beta = 0.7','Beta = 0.8','Beta = 0.9','Beta = 1.0');
    %legend('5xQ','10xQ','15xQ','20xQ','25xQ','30xQ','35xQ','40xQ','45xQ','50xQ','55xQ','60xQ','65xQ','70xQ','75xQ','80xQ','85xQ','90xQ','95xQ','100xQ');
